# patika.dev-C-101
C#101 dersi hakkında tüm ödevler bu kısımda yer alacaktır 
