# html-odevleri-patika.dev
Html konusunu öğrenirken yapılan odevler
