1.SORU
-- SELECT title , description FROM film
2.SORU
-- SELECT * FROM film
-- WHERE  length>60 AND length<75 
3.SORU     
-- WHERE rental_rate = 0.99 AND replacement_cost = 12.99 OR replacement_cost = 28.99 ;
4.SORU 
-- SELECT * FROM customer     
-- WHERE first_name = 'Mary' ; last_name = (Smith)
5.SORU
-- SELECT * FROM film
-- WHERE NOT (length >50 OR rental_rate = 2.99 OR rental_rate = 4.99) ;
